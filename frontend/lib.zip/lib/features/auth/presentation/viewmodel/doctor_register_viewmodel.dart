import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'base_auth_viewmodel.dart';

class DoctorRegisterViewModel extends BaseAuthViewModel {
  // TextEditingControllers
  final formKey = GlobalKey<FormState>();

  final fullNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final dobController = TextEditingController();
  final licenseNumberController = TextEditingController();
  final licenseAuthorityController = TextEditingController();
  final licenseExpiryController = TextEditingController();
  final specializationController = TextEditingController();
  final experienceController = TextEditingController();
  final hospitalController = TextEditingController();
  final workAddressController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  // Form state
  final RxString gender = ''.obs;
  final RxBool termsAccepted = false.obs;
  final RxBool obscurePassword = true.obs;
  final RxBool obscureConfirmPassword = true.obs;

  // File uploads
  dynamic licenseFile;
  dynamic idFile;
  dynamic profilePhoto;
  dynamic signatureFile;
  dynamic stampFile;

  void togglePasswordVisibility() {
    obscurePassword.value = !obscurePassword.value;
  }

  void toggleConfirmPasswordVisibility() {
    obscureConfirmPassword.value = !obscureConfirmPassword.value;
  }

  void setFile(String field, dynamic file) {
    switch (field) {
      case 'license':
        licenseFile = file;
        break;
      case 'id':
        idFile = file;
        break;
      case 'photo':
        profilePhoto = file;
        break;
      case 'signature':
        signatureFile = file;
        break;
      case 'stamp':
        stampFile = file;
        break;
    }
  }

  Future<void> selectDate(BuildContext context, TextEditingController controller, {bool isFutureDate = false}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(1990),
      firstDate: DateTime(1900),
      lastDate: isFutureDate ? DateTime(2100) : DateTime.now(),
    );
    if (picked != null) {
      controller.text = "${picked.year}-${picked.month}-${picked.day}";
    }
  }

  /// Validation Methods
  String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Full name is required';
    }
    return null;
  }

  String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email is required';
    }
    if (!GetUtils.isEmail(value.trim())) {
      return 'Enter a valid email address';
    }
    return null;
  }

  String? validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Phone number is required';
    }
    if (!RegExp(r'^[0-9]{10,15}$').hasMatch(value.trim())) {
      return 'Enter a valid phone number';
    }
    return null;
  }

  String? validateLicenseNumber(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'License number is required';
    }
    return null;
  }

  String? validateExperience(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Experience is required';
    }
    final number = int.tryParse(value);
    if (number == null || number < 0) {
      return 'Enter a valid number of years';
    }
    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  String? validateConfirmPasswordField(String? value) {
    if (value != passwordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }

  /// Main Registration Logic
  Future<void> registerDoctor() async {
    if (!termsAccepted.value) {
      handleError('Please accept the terms and conditions.');
      return;
    }

    if (!formKey.currentState!.validate()) return;

    showLoading();

    final success = await authRepository.registerDoctor(
      fullName: fullNameController.text.trim(),
      email: emailController.text.trim(),
      phone: phoneController.text.trim(),
      dob: dobController.text.trim(),
      gender: gender.value,
      licenseNumber: licenseNumberController.text.trim(),
      licenseAuthority: licenseAuthorityController.text.trim(),
      licenseExpiry: licenseExpiryController.text.trim(),
      specialization: specializationController.text.trim(),
      experience: int.tryParse(experienceController.text.trim()) ?? 0,
      hospital: hospitalController.text.trim(),
      workAddress: workAddressController.text.trim(),
      password: passwordController.text.trim(),
      licenseFile: licenseFile,
      idFile: idFile,
      profilePhoto: profilePhoto,
      signatureFile: signatureFile,
      stampFile: stampFile,
    );

    hideLoading();

    if (success) {
      handleSuccess("Doctor registered successfully!");
      // TODO: Navigate to dashboard or success screen
    }
  }

  @override
  void onClose() {
    // Dispose controllers
    fullNameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    dobController.dispose();
    licenseNumberController.dispose();
    licenseAuthorityController.dispose();
    licenseExpiryController.dispose();
    specializationController.dispose();
    experienceController.dispose();
    hospitalController.dispose();
    workAddressController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }
}
