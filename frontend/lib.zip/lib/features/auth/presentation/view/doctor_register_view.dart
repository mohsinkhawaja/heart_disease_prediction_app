import 'package:flutter/material.dart';
import 'package:frontend/features/auth/presentation/widgets/password_strength_indicator.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_fonts.dart';
import '../../../../routes/app_routes.dart';
import '../viewmodel/doctor_register_viewmodel.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/auth_button.dart';
import '../widgets/file_upload_field.dart';

class DoctorRegisterView extends StatelessWidget {
  const DoctorRegisterView({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.put(DoctorRegisterViewModel());

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(
          "Doctor Registration",
          style: AppFonts.heading2.copyWith(color: AppColors.whiteColor),
        ),
        backgroundColor: AppColors.primaryColor,
        elevation: 0,
        centerTitle: true,
      ),
      body: SafeArea(
        child: Form(
          key: viewModel.formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),

                // Header
                Text(
                  'Medical Professional Registration',
                  style: AppFonts.heading1.copyWith(
                    color: AppColors.primaryColor,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Join our network of healthcare professionals',
                  style: AppFonts.bodyLarge.copyWith(
                    color: AppColors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),

                // Personal Information Section
                _buildSectionHeader('Personal Information'),

                CustomTextField(
                  controller: viewModel.fullNameController,
                  label: 'Full Name',
                  prefixIcon: const Icon(
                    Icons.person_outline,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateName,
                ),

                CustomTextField(
                  controller: viewModel.emailController,
                  label: 'Email Address',
                  keyboardType: TextInputType.emailAddress,
                  prefixIcon: const Icon(
                    Icons.email_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateEmail,
                ),

                CustomTextField(
                  controller: viewModel.phoneController,
                  label: 'Phone Number',
                  keyboardType: TextInputType.phone,
                  prefixIcon: const Icon(
                    Icons.phone_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validatePhone,
                ),

                CustomTextField(
                  controller: viewModel.dobController,
                  label: 'Date of Birth',
                  readOnly: true,
                  prefixIcon: const Icon(
                    Icons.cake_outlined,
                    color: AppColors.primaryColor,
                  ),
                  suffixIcon: const Icon(
                    Icons.calendar_today,
                    color: AppColors.primaryColor,
                  ),
                  onTap:
                      () => viewModel.selectDate(
                        context,
                        viewModel.dobController,
                      ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Date of birth is required'
                              : null,
                ),

                // Gender Selection
                const SizedBox(height: 16),
                Text(
                  'Gender',
                  style: AppFonts.labelText.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Obx(
                  () => Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.borderColor),
                      borderRadius: BorderRadius.circular(12),
                      color: AppColors.cardColor,
                    ),
                    child: Row(
                      children:
                          ['Male', 'Female', 'Other'].map((gender) {
                            return Expanded(
                              child: RadioListTile<String>(
                                title: Text(gender, style: AppFonts.bodyMedium),
                                value: gender,
                                groupValue: viewModel.gender.value,
                                onChanged:
                                    (value) => viewModel.gender.value = value!,
                                activeColor: AppColors.primaryColor,
                              ),
                            );
                          }).toList(),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // Professional Information Section
                _buildSectionHeader('Professional Information'),

                CustomTextField(
                  controller: viewModel.licenseNumberController,
                  label: 'Medical License Number',
                  prefixIcon: const Icon(
                    Icons.badge_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateLicenseNumber,
                ),

                CustomTextField(
                  controller: viewModel.licenseAuthorityController,
                  label: 'License Issuing Authority',
                  prefixIcon: const Icon(
                    Icons.account_balance_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Authority is required'
                              : null,
                ),

                CustomTextField(
                  controller: viewModel.licenseExpiryController,
                  label: 'License Expiry Date',
                  readOnly: true,
                  prefixIcon: const Icon(
                    Icons.date_range_outlined,
                    color: AppColors.primaryColor,
                  ),
                  suffixIcon: const Icon(
                    Icons.calendar_today,
                    color: AppColors.primaryColor,
                  ),
                  onTap:
                      () => viewModel.selectDate(
                        context,
                        viewModel.licenseExpiryController,
                        isFutureDate: true,
                      ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Expiry date is required'
                              : null,
                ),

                CustomTextField(
                  controller: viewModel.specializationController,
                  label: 'Medical Specialization',
                  prefixIcon: const Icon(
                    Icons.local_hospital_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Specialization is required'
                              : null,
                ),

                CustomTextField(
                  controller: viewModel.experienceController,
                  label: 'Years of Experience',
                  keyboardType: TextInputType.number,
                  prefixIcon: const Icon(
                    Icons.work_outline,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateExperience,
                ),

                CustomTextField(
                  controller: viewModel.hospitalController,
                  label: 'Hospital/Clinic Name',
                  prefixIcon: const Icon(
                    Icons.business_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Hospital/Clinic is required'
                              : null,
                ),

                CustomTextField(
                  controller: viewModel.workAddressController,
                  label: 'Work Address',
                  maxLines: 3,
                  prefixIcon: const Icon(
                    Icons.location_on_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator:
                      (value) =>
                          value?.isEmpty == true
                              ? 'Work address is required'
                              : null,
                ),

                const SizedBox(height: 24),

                // Document Upload Section
                _buildSectionHeader('Required Documents'),

                FileUploadField(
                  label: 'Medical License Certificate',
                  onFileSelected: (file) => viewModel.setFile('license', file!),
                  isRequired: true,
                ),

                FileUploadField(
                  label: 'Government-issued ID',
                  onFileSelected: (file) => viewModel.setFile('id', file!),
                  isRequired: true,
                ),

                FileUploadField(
                  label: 'Professional Profile Photo',
                  onFileSelected: (file) => viewModel.setFile('photo', file!),
                  imageOnly: true,
                  isRequired: true,
                ),

                FileUploadField(
                  label: 'Digital Signature',
                  onFileSelected:
                      (file) => viewModel.setFile('signature', file!),
                  imageOnly: true,
                  isRequired: true,
                ),

                FileUploadField(
                  label: 'Official Medical Stamp',
                  onFileSelected: (file) => viewModel.setFile('stamp', file!),
                  imageOnly: true,
                  isRequired: true,
                ),

                const SizedBox(height: 24),

                // Security Section
                _buildSectionHeader('Account Security'),

                Obx(
                  () => CustomTextField(
                    controller: viewModel.passwordController,
                    label: 'Password',
                    obscureText: viewModel.obscurePassword.value,
                    prefixIcon: const Icon(
                      Icons.lock_outline,
                      color: AppColors.primaryColor,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        viewModel.obscurePassword.value
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: AppColors.primaryColor,
                      ),
                      onPressed: viewModel.togglePasswordVisibility,
                    ),
                    validator: viewModel.validatePassword,
                  ),
                ),
                // Password Strength Indicator
                GetBuilder<DoctorRegisterViewModel>(
                  builder:
                      (controller) => PasswordStrengthIndicator(
                        password: controller.passwordController.text,
                      ),
                ),

                Obx(
                  () => CustomTextField(
                    controller: viewModel.confirmPasswordController,
                    label: 'Confirm Password',
                    obscureText: viewModel.obscureConfirmPassword.value,
                    prefixIcon: const Icon(
                      Icons.lock_outline,
                      color: AppColors.primaryColor,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        viewModel.obscureConfirmPassword.value
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: AppColors.primaryColor,
                      ),
                      onPressed: viewModel.toggleConfirmPasswordVisibility,
                    ),
                    validator: viewModel.validateConfirmPasswordField,
                  ),
                ),

                const SizedBox(height: 24),

                // Terms & Conditions
                Obx(
                  () => CheckboxListTile(
                    title: Text(
                      "I confirm that all information provided is accurate and I agree to the terms and conditions for medical professionals.",
                      style: AppFonts.bodyMedium,
                    ),
                    value: viewModel.termsAccepted.value,
                    onChanged:
                        (value) =>
                            viewModel.termsAccepted.value = value ?? false,
                    activeColor: AppColors.primaryColor,
                    controlAffinity: ListTileControlAffinity.leading,
                  ),
                ),

                const SizedBox(height: 24),

                // Register Button
                Obx(
                  () => AuthButton(
                    text: "Submit Registration",
                    isLoading: viewModel.isLoading.value,
                    icon: Icons.send,
                    onPressed: viewModel.registerDoctor,
                  ),
                ),

                const SizedBox(height: 16),

                // Login Link
                TextButton(
                  onPressed: () => Get.toNamed(AppRoutes.doctorLogin),
                  child: Text(
                    "Already have an account? Login",
                    style: AppFonts.bodyMedium.copyWith(
                      color: AppColors.secondaryColor,
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Registration Notice
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.warningColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.warningColor.withOpacity(0.3),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: AppColors.warningColor,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Registration Review Process',
                            style: AppFonts.labelText.copyWith(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '• Your registration will be reviewed by our medical verification team\n'
                        '• All documents will be verified for authenticity\n'
                        '• You will receive an email notification once approved\n'
                        '• This process typically takes 2-3 business days',
                        style: AppFonts.bodySmall.copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        title,
        style: AppFonts.heading3.copyWith(color: AppColors.primaryColor),
      ),
    );
  }
}
