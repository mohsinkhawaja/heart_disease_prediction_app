import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_fonts.dart';
import '../../../../routes/app_routes.dart';
import '../viewmodel/doctor_login_viewmodel.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/auth_button.dart';
import '../widgets/password_strength_indicator.dart';

class DoctorLoginView extends StatelessWidget {
  const DoctorLoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.put(DoctorLoginViewModel());

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(
          "Doctor Login",
          style: AppFonts.heading2.copyWith(color: AppColors.whiteColor),
        ),
        backgroundColor: AppColors.primaryColor,
        elevation: 0,
        centerTitle: true,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight - 48, // Account for padding
                ),
                child: Form(
                  key: viewModel.formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      
                      // Welcome Section
                      Text(
                        'Welcome Doctor!',
                        style: AppFonts.heading1.copyWith(
                          color: AppColors.primaryColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Login to your medical dashboard',
                        style: AppFonts.bodyLarge.copyWith(
                          color: AppColors.textSecondary,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),

                      // Email Field
                      CustomTextField(
                        controller: viewModel.emailController,
                        label: "Email Address",
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: const Icon(
                          Icons.email_outlined,
                          color: AppColors.primaryColor,
                        ),
                        validator: viewModel.validateEmail,
                      ),

                      // Password Field
                      GetBuilder<DoctorLoginViewModel>(
                        builder: (controller) => CustomTextField(
                          controller: controller.passwordController,
                          label: "Password",
                          obscureText: controller.obscurePassword.value,
                          prefixIcon: const Icon(
                            Icons.lock_outline,
                            color: AppColors.primaryColor,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              controller.obscurePassword.value
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined,
                              color: AppColors.primaryColor,
                            ),
                            onPressed: controller.togglePasswordVisibility,
                          ),
                          validator: controller.validatePassword,
                          onChanged: controller.checkPasswordStrength,
                        ),
                      ),

                      // Password Strength Indicator
                      GetBuilder<DoctorLoginViewModel>(
                        builder: (controller) => PasswordStrengthIndicator(
                          password: controller.passwordController.text,
                        ),
                      ),

                      const SizedBox(height: 28),

                      // Login Button
                      GetBuilder<DoctorLoginViewModel>(
                        builder: (controller) => AuthButton(
                          text: "Login",
                          isLoading: controller.isLoading.value,
                          icon: Icons.medical_services,
                          onPressed: controller.login,
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Forgot Password
                      TextButton(
                        onPressed: () => Get.toNamed(AppRoutes.forgotPassword),
                        child: Text(
                          'Forgot Password?',
                          style: AppFonts.bodyMedium.copyWith(
                            color: AppColors.primaryColor,
                          ),
                        ),
                      ),

                      // Register Link
                      TextButton(
                        onPressed: () => Get.toNamed(AppRoutes.doctorRegister),
                        child: Text(
                          "Don't have an account? Register",
                          style: AppFonts.bodyMedium.copyWith(
                            color: AppColors.secondaryColor,
                          ),
                        ),
                      ),

                      const SizedBox(height: 16),
                      const Divider(color: AppColors.borderColor),
                      const SizedBox(height: 16),

                      // Professional Notice
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.infoColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppColors.infoColor.withOpacity(0.3),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              color: AppColors.infoColor,
                              size: 20,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'Doctor accounts require admin approval before activation',
                                style: AppFonts.bodySmall.copyWith(
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 20), // Bottom padding
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}