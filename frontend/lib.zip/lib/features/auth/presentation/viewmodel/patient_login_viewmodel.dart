// This should be in: features/auth/presentation/viewmodel/patient_login_viewmodel.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PatientLoginViewModel extends GetxController {
  // Form key
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  
  // Controllers
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  
  // Observable variables
  final RxBool obscurePassword = true.obs;
  final RxBool isLoading = false.obs;
  final RxString passwordStrength = ''.obs;
  
  // Methods
  void togglePasswordVisibility() {
    obscurePassword.value = !obscurePassword.value;
    update(); // Notify GetBuilder widgets
  }
  
  void checkPasswordStrength(String password) {
    passwordStrength.value = password;
    update(); // Notify GetBuilder widgets
  }
  
  String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    if (!GetUtils.isEmail(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }
  
  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters';
    }
    return null;
  }
  
  Future<void> login() async {
    if (!formKey.currentState!.validate()) return;
    
    try {
      isLoading.value = true;
      update();
      
      // Your login logic here
      await Future.delayed(const Duration(seconds: 2)); // Simulate API call
      
      // Navigate to patient dashboard
      Get.offNamed('/patient-dashboard'); // Update with your actual route
      
      Get.snackbar(
        'Success',
        'Login successful!',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
      
    } catch (e) {
      Get.snackbar(
        'Error', 
        'Login failed: ${e.toString()}',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
      update();
    }
  }
  
  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    super.onClose();
  }
}