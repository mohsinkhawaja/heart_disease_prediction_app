import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_fonts.dart';
import '../../../../routes/app_routes.dart';
import '../viewmodel/patient_login_viewmodel.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/auth_button.dart';
import '../widgets/password_strength_indicator.dart';

class PatientLoginView extends StatelessWidget {
  const PatientLoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.put(PatientLoginViewModel());

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(
          "Patient Login",
          style: AppFonts.heading2.copyWith(color: AppColors.whiteColor),
        ),
        backgroundColor: AppColors.primaryColor,
        elevation: 0,
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: viewModel.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),

                // Welcome Section
                Text(
                  'Welcome Back!',
                  style: AppFonts.heading1.copyWith(
                    color: AppColors.primaryColor,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Login to your patient account',
                  style: AppFonts.bodyLarge.copyWith(
                    color: AppColors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),

                // Email Field
                CustomTextField(
                  controller: viewModel.emailController,
                  label: "Email Address",
                  keyboardType: TextInputType.emailAddress,
                  prefixIcon: const Icon(
                    Icons.email_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateEmail,
                ),

                // Password Field
                Obx(
                  () => CustomTextField(
                    controller: viewModel.passwordController,
                    label: "Password",
                    obscureText: viewModel.obscurePassword.value,
                    prefixIcon: const Icon(
                      Icons.lock_outline,
                      color: AppColors.primaryColor,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        viewModel.obscurePassword.value
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: AppColors.primaryColor,
                      ),
                      onPressed: viewModel.togglePasswordVisibility,
                    ),
                    validator: viewModel.validatePassword,
                    onChanged: viewModel.checkPasswordStrength,
                  ),
                ),

                // Password Strength Indicator
                GetBuilder<PatientLoginViewModel>(
                  builder:
                      (controller) => PasswordStrengthIndicator(
                        password: controller.passwordController.text,
                      ),
                ),

                const SizedBox(height: 28),

                // Login Button
                Obx(
                  () => AuthButton(
                    text: "Login",
                    isLoading: viewModel.isLoading.value,
                    onPressed: viewModel.login,
                  ),
                ),

                const SizedBox(height: 16),

                // Forgot Password
                TextButton(
                  onPressed: () => Get.toNamed(AppRoutes.forgotPassword),
                  child: Text(
                    'Forgot Password?',
                    style: AppFonts.bodyMedium.copyWith(
                      color: AppColors.primaryColor,
                    ),
                  ),
                ),

                // Register Link
                TextButton(
                  onPressed: () => Get.toNamed(AppRoutes.patientRegister),
                  child: Text(
                    "Don't have an account? Sign Up",
                    style: AppFonts.bodyMedium.copyWith(
                      color: AppColors.secondaryColor,
                    ),
                  ),
                ),

                const SizedBox(height: 16),
                const Divider(color: AppColors.borderColor),
                const SizedBox(height: 16),

                // Google Sign In
                SizedBox(
                  height: 48,
                  child: OutlinedButton.icon(
                    icon: Image.asset(
                      'assets/images/google_logo.png',
                      height: 24,
                      errorBuilder:
                          (context, error, stackTrace) =>
                              const Icon(Icons.g_mobiledata, size: 24),
                    ),
                    label: Text(
                      'Sign in with Google',
                      style: AppFonts.buttonText.copyWith(
                        color: AppColors.textPrimary,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textPrimary,
                      side: const BorderSide(color: AppColors.borderColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      backgroundColor: AppColors.whiteColor,
                    ),
                    onPressed: () {
                      // TODO: Implement Google Sign-In
                      Get.snackbar(
                        'Coming Soon',
                        'Google Sign-In will be available soon',
                        backgroundColor: AppColors.infoColor,
                        colorText: AppColors.whiteColor,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
