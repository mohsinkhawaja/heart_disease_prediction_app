import 'package:get/get.dart';
import '../features/auth/presentation/view/splash/splash_view.dart';
import '../features/auth/presentation/view/user_type_selection_view.dart';
import '../features/auth/presentation/view/patient_login_view.dart';
import '../features/auth/presentation/view/patient_register_view.dart';
import '../features/auth/presentation/view/doctor_login_view.dart';
import '../features/auth/presentation/view/doctor_register_view.dart';
import '../features/auth/presentation/view/forgot_password_view.dart';
import '../features/auth/presentation/view/otp_verification_view.dart';
import '../features/auth/presentation/view/reset_password_view.dart';
import '../features/auth/presentation/viewmodel/patient_login_viewmodel.dart';
import '../features/auth/presentation/viewmodel/patient_register_viewmodel.dart';
import '../features/auth/presentation/viewmodel/doctor_login_viewmodel.dart';
import '../features/auth/presentation/viewmodel/doctor_register_viewmodel.dart';
import '../features/auth/presentation/viewmodel/forgot_password_viewmodel.dart';
import '../features/auth/presentation/viewmodel/otp_verification_viewmodel.dart';
import '../features/auth/presentation/viewmodel/reset_password_viewmodel.dart';
import 'app_routes.dart';

class AppPages {
  static final routes = [
    // Splash
    GetPage(
      name: AppRoutes.splash,
      page: () => const SplashView(),
    ),
    
    // User Type Selection
    GetPage(
      name: AppRoutes.userType,
      page: () => const UserTypeSelectionView(),
    ),
    
    // Patient Auth
    GetPage(
      name: AppRoutes.patientLogin,
      page: () => const PatientLoginView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<PatientLoginViewModel>(() => PatientLoginViewModel());
      }),
    ),
    GetPage(
      name: AppRoutes.patientRegister,
      page: () => const PatientRegisterView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<PatientRegisterViewModel>(() => PatientRegisterViewModel());
      }),
    ),
    
    // Doctor Auth
    GetPage(
      name: AppRoutes.doctorLogin,
      page: () => const DoctorLoginView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<DoctorLoginViewModel>(() => DoctorLoginViewModel());
      }),
    ),
    GetPage(
      name: AppRoutes.doctorRegister,
      page: () =>  DoctorRegisterView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<DoctorRegisterViewModel>(() => DoctorRegisterViewModel());
      }),
    ),
    
    // Password Reset Flow
    GetPage(
      name: AppRoutes.forgotPassword,
      page: () => const ForgotPasswordView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<ForgotPasswordViewModel>(() => ForgotPasswordViewModel());
      }),
    ),
    GetPage(
      name: AppRoutes.otpVerification,
      page: () => const OtpVerificationView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<OtpVerificationViewModel>(() => OtpVerificationViewModel());
      }),
    ),
    GetPage(
      name: AppRoutes.resetPassword,
      page: () => ResetPasswordView(),
      binding: BindingsBuilder(() {
        Get.lazyPut<ResetPasswordViewModel>(() => ResetPasswordViewModel());
      }),
    ),
    
    // TODO: Add dashboard and other feature routes
  ];
}