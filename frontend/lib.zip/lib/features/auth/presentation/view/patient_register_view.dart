import 'package:flutter/material.dart';
import 'package:frontend/features/auth/presentation/viewmodel/patient_login_viewmodel.dart';
import 'package:get/get.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_fonts.dart';
import '../../../../routes/app_routes.dart';
import '../viewmodel/patient_register_viewmodel.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/auth_button.dart';
import '../widgets/password_strength_indicator.dart';

class PatientRegisterView extends StatelessWidget {
  const PatientRegisterView({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.put(PatientRegisterViewModel());

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(
          "Patient Registration",
          style: AppFonts.heading2.copyWith(color: AppColors.whiteColor),
        ),
        backgroundColor: AppColors.primaryColor,
        elevation: 0,
        centerTitle: true,
      ),
      body: SafeArea(
        child: Form(
          key: viewModel.formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                
                // Header
                Text(
                  'Create Patient Account',
                  style: AppFonts.heading1.copyWith(
                    color: AppColors.primaryColor,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Join our heart health monitoring platform',
                  style: AppFonts.bodyLarge.copyWith(
                    color: AppColors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),

                // Full Name
                CustomTextField(
                  controller: viewModel.fullNameController,
                  label: 'Full Name',
                  prefixIcon: const Icon(
                    Icons.person_outline,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateName,
                ),

                // Email
                CustomTextField(
                  controller: viewModel.emailController,
                  label: 'Email Address',
                  keyboardType: TextInputType.emailAddress,
                  prefixIcon: const Icon(
                    Icons.email_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateEmail,
                ),

                // Password
                Obx(() => CustomTextField(
                  controller: viewModel.passwordController,
                  label: 'Password',
                  obscureText: viewModel.obscurePassword.value,
                  prefixIcon: const Icon(
                    Icons.lock_outline,
                    color: AppColors.primaryColor,
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      viewModel.obscurePassword.value
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppColors.primaryColor,
                    ),
                    onPressed: viewModel.togglePasswordVisibility,
                  ),
                  validator: viewModel.validatePassword,
                  onChanged: viewModel.checkPasswordStrength,
                )),

              // Password Strength Indicator
                GetBuilder<PatientLoginViewModel>(
                  builder:
                      (controller) => PasswordStrengthIndicator(
                        password: controller.passwordController.text,
                      ),
                ),


                // Confirm Password
                Obx(() => CustomTextField(
                  controller: viewModel.confirmPasswordController,
                  label: 'Confirm Password',
                  obscureText: viewModel.obscureConfirmPassword.value,
                  prefixIcon: const Icon(
                    Icons.lock_outline,
                    color: AppColors.primaryColor,
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      viewModel.obscureConfirmPassword.value
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppColors.primaryColor,
                    ),
                    onPressed: viewModel.toggleConfirmPasswordVisibility,
                  ),
                  validator: viewModel.validateConfirmPasswordField,
                )),

                // Age
                CustomTextField(
                  controller: viewModel.ageController,
                  label: 'Age',
                  keyboardType: TextInputType.number,
                  prefixIcon: const Icon(
                    Icons.cake_outlined,
                    color: AppColors.primaryColor,
                  ),
                  validator: viewModel.validateAge,
                ),

                // Gender Selection
                const SizedBox(height: 16),
                Text(
                  'Gender',
                  style: AppFonts.labelText.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Obx(() => Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.borderColor),
                    borderRadius: BorderRadius.circular(12),
                    color: AppColors.cardColor,
                  ),
                  child: Row(
                    children: ['Male', 'Female', 'Other'].map((gender) {
                      return Expanded(
                        child: RadioListTile<String>(
                          title: Text(
                            gender,
                            style: AppFonts.bodyMedium,
                          ),
                          value: gender,
                          groupValue: viewModel.gender.value,
                          onChanged: (value) => viewModel.gender.value = value!,
                          activeColor: AppColors.primaryColor,
                        ),
                      );
                    }).toList(),
                  ),
                )),

                // Medical History
                const SizedBox(height: 16),
                CustomTextField(
                  controller: viewModel.medicalHistoryController,
                  label: 'Medical History (Optional)',
                  maxLines: 4,
                  prefixIcon: const Icon(
                    Icons.medical_information_outlined,
                    color: AppColors.primaryColor,
                  ),
                  hintText: 'Enter any relevant medical history...',
                ),

                // Terms & Conditions
                const SizedBox(height: 16),
                Obx(() => CheckboxListTile(
                  title: Text(
                    "I agree to the Terms & Conditions and Privacy Policy",
                    style: AppFonts.bodyMedium,
                  ),
                  value: viewModel.termsAccepted.value,
                  onChanged: (value) => viewModel.termsAccepted.value = value ?? false,
                  activeColor: AppColors.primaryColor,
                  controlAffinity: ListTileControlAffinity.leading,
                )),

                const SizedBox(height: 24),

                // Register Button
                Obx(() => AuthButton(
                  text: "Create Account",
                  isLoading: viewModel.isLoading.value,
                  icon: Icons.person_add,
                  onPressed: viewModel.registerPatient,
                )),

                const SizedBox(height: 16),

                // Login Link
                TextButton(
                  onPressed: () => Get.toNamed(AppRoutes.patientLogin),
                  child: Text(
                    "Already have an account? Login",
                    style: AppFonts.bodyMedium.copyWith(
                      color: AppColors.secondaryColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}