import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../routes/app_routes.dart';
import '../../../../core/services/validation_service.dart';
import 'base_auth_viewmodel.dart';

class PatientRegisterViewModel extends BaseAuthViewModel {
  // Controllers
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController medicalHistoryController = TextEditingController();

  // Reactive variables
  final RxString gender = 'Male'.obs;
  final RxBool obscurePassword = true.obs;
  final RxBool obscureConfirmPassword = true.obs;
  final RxBool termsAccepted = false.obs;
  final RxString passwordStrength = ''.obs;
  final Rx<Color> strengthColor = Colors.grey.obs;

  // Validation methods
  String? validateName(String? value) => ValidationService.validateName(value);
  String? validateAge(String? value) => ValidationService.validateAge(value);
  String? validateConfirmPasswordField(String? value) => 
    validateConfirmPassword(value, passwordController.text);

  void togglePasswordVisibility() {
    obscurePassword.value = !obscurePassword.value;
  }

  void toggleConfirmPasswordVisibility() {
    obscureConfirmPassword.value = !obscureConfirmPassword.value;
  }

  void checkPasswordStrength(String value) {
    final strength = ValidationService.getPasswordStrength(value);
    switch (strength) {
      case PasswordStrength.weak:
        passwordStrength.value = 'Weak';
        strengthColor.value = Colors.red;
        break;
      case PasswordStrength.medium:
        passwordStrength.value = 'Medium';
        strengthColor.value = Colors.orange;
        break;
      case PasswordStrength.strong:
        passwordStrength.value = 'Strong';
        strengthColor.value = Colors.green;
        break;
    }
  }

  Future<void> registerPatient() async {
    if (!formKey.currentState!.validate()) return;

    if (!termsAccepted.value) {
      handleError('You must accept the terms and conditions');
      return;
    }

    showLoading();

    try {
      final success = await authRepository.registerPatient(
        email: emailController.text.trim(),
        password: passwordController.text,
        fullName: fullNameController.text.trim(),
        age: int.parse(ageController.text),
        gender: gender.value,
        medicalHistory: medicalHistoryController.text.trim().isEmpty 
          ? null 
          : medicalHistoryController.text.trim(),
      );

      if (success) {
        handleSuccess('Registration successful! Please login to continue.');
        Get.offAllNamed(AppRoutes.patientLogin);
      } else {
        handleError('Registration failed. Email might already be in use.');
      }
    } catch (e) {
      handleError('Registration failed: ${e.toString()}');
    } finally {
      hideLoading();
    }
  }

  @override
  void onClose() {
    fullNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    ageController.dispose();
    medicalHistoryController.dispose();
    super.onClose();
  }
}